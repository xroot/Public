<?php
/*
	This file is part of Hyla
	Copyright (c) 2004-2006 Charles Rincheval.
	All rights reserved

	Hyla is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published
	by the Free Software Foundation; either version 2 of the License,
	or (at your option) any later version.

	Hyla is distributed in the hope that it will be useful, but
	WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Hyla; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

if (!defined('PAGE_HOME'))
	header('location: ../index.php');

require 'src/inc/system.class.php';

error_reporting(E_ERROR);		// E_ERROR | E_USER_ERROR

set_magic_quotes_runtime(0);

if (basename($_SERVER['PHP_SELF']) != 'install.php') {
	if (file_exists('install.php')) {
		system::end('You must remove the file install.php !');
	}
	if (!file_exists('conf/config.inc.php')) {
		system::end('The configuration file doesn\'t exist !');
	} else
		require 'conf/config.inc.php';
}

define('DIR_ROOT', dirname($_SERVER['SCRIPT_FILENAME']).'/');

require 'src/inc/define.php';
require 'src/lib/class.ini.file.php';
require 'src/inc/function.inc.php';

$conf = array();
load_config();

register_shutdown_function(array('system', 'timeOut'));

define('FILE_L10N', 'l10n/'.$conf['lng'].'/messages.php');
require FILE_L10N;

define('DIR_TEMPLATE', 	'tpl/'.$conf['name_template']);

define('HYLA_VERSION',	'0.6.0');

?>
