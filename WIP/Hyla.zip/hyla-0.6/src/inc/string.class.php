<?php
/*
	This file is part of Hyla
	Copyright (c) 2004-2006 Charles Rincheval.
	All rights reserved

	Hyla is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published
	by the Free Software Foundation; either version 2 of the License,
	or (at your option) any later version.

	Hyla is distributed in the hope that it will be useful, but
	WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Hyla; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


class string
{
	/*	Renvoie le nombre de mots demand� dans une phrase
		@param	string	$str La phrase
	 	@param	int		$nbr_word Nombre de mots souhait�s
	 */
	function cutWord($str, $nbr_word) {
		$tab_word = array();
		$tab_word = explode(' ', $str);
		for ($i = 0, $word = null; $i < $nbr_word; $i++)
			$word .= $tab_word[$i].' ';
		return $word;
	}

	/*	Coupe un mot ou une phrase et rajoute des '...'
		@param	string	$str Chaine � couper
	 	@param	int		$size Taille de la coupe
		@param	string	$end Tronquer avec ce string
	 */
	function cut($str, $size = 25, $end = '...') {
		if (strlen($str) > $size)
			$str = substr($str, 0, $size - strlen($end)).$end;
	
		return $str;
	}

	/*	On ne tient pas compte des accents !
		@param	string	$str Chaine de caract�res !
		@param	bool	$_lower Si � true, renvoie la chaine en miniscule
	 */
	function skipAccent($str, $_lower = false) {
		$str = ($_lower) ? strtolower($str) : $str;
		$tofind = "�����������������������������������������������������";
		$replac = "AAAAAAaaaaaaOOOOOOooooooEEEEeeeeCcIIIIiiiiUUUUuuuuyNn";
		return strtr($str, $tofind, $replac);
	}

	/*	Recherche une chaine de caract�re dans un ensemble de caract�res (strpbrk en php5)
		@param	string	$str	La chaine � v�rifier
		@param	string	$list	Liste de caract�re
		@return	Retourne true si la chaine contient un des caract�re pass� en second param�tre
	 */
	function test($str, $list) {
		$ret = false;
		$size = strlen($list);
		for ($i = 0, $var = null; $i < $size; $i++) {
			if ($str{0} == $list{$i} || strpos($str, $list{$i})) {
				$ret = true;
				break;
			}
		}
		return $ret;
	}

	/*	Format une chaine comme il faut !
		@param	string	$string	La chaine � formater
		@param	bool	$n		Accepter les retour chariot ou non
	 */
	function format($string, $n = true) {
//		$string = htmlspecialchars($string, ENT_QUOTES);
		$string = htmlentities($string, ENT_QUOTES);

		// Le nl2br rajoute un retour chariot apr�s le <br /> donc :
		$string = ($n) ? eregi_replace("\r\n|\n", '<br />', $string) : eregi_replace("\r\n|\n", ' ', $string);

		return $string;
	}

	/*	Op�ration inverse de formatString
		@param	string	$string	La chaine � "d�formater"
	 */
	function unFormat($string, $n = true) {
		if ($n)
			$string = eregi_replace("<br />|<br>", "\n", $string);

		return $string;
	}
}

?>
