# api/permissions.py

from rest_framework.permissions import BasePermission


class HasDjangoPermission(BasePermission):
    """
    Vérifie qu'un utilisateur authentifié possède
    la permission Django demandée par la vue.

    La vue doit définir :

        required_permission = "app_label.codename"
    """

    required_permission = None

    def has_permission(self, request, view):
        user = request.user

        if not user or not user.is_authenticated:
            return False

        permission = getattr(view, "required_permission", None)

        if not permission:
            return False

        return user.has_perm(permission)
