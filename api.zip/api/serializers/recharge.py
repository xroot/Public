# api/serializers/recharge.py
from rest_framework import serializers

from cycles.models import RechargeCycle


class RechargeCycleSerializer(serializers.ModelSerializer):
    """
    Serializer de lecture d'une sous-tontine Recharge SPARK.

    Les données financières calculées proviennent directement du moteur
    métier de RechargeCycle (pas de recalcul ici).
    """

    total_cotisations = serializers.DecimalField(
        max_digits=15, decimal_places=2, read_only=True,
    )
    total_acquis = serializers.DecimalField(
        max_digits=15, decimal_places=2, read_only=True,
    )
    reste_a_acquerir = serializers.DecimalField(
        max_digits=15, decimal_places=2, read_only=True,
    )
    progression = serializers.DecimalField(
        max_digits=6, decimal_places=2, read_only=True,
    )

    objectif_atteint = serializers.SerializerMethodField()
    cycle_numero = serializers.SerializerMethodField()
    cycle_origine_numero = serializers.SerializerMethodField()

    class Meta:
        model = RechargeCycle
        fields = (
            "id",
            "cycle",
            "cycle_numero",
            "client",
            "cycle_origine",
            "cycle_origine_numero",
            "objectif",
            "montant_initial",
            "solde",
            "statut",
            "date_debut",
            "date_fin",
            "date_cloture",
            "total_cotisations",
            "total_acquis",
            "reste_a_acquerir",
            "progression",
            "objectif_atteint",
            "created_at",
            "updated_at",
        )
        read_only_fields = fields

    def get_objectif_atteint(self, obj):
        return obj.objectif_atteint()

    def get_cycle_numero(self, obj):
        if obj.cycle_id:
            return obj.cycle.numero
        return None

    def get_cycle_origine_numero(self, obj):
        if obj.cycle_origine_id:
            return obj.cycle_origine.numero
        return None
