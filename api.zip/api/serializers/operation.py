# api/serializers/operation.py

from rest_framework import serializers

from cycles.models import Operation


class OperationSerializer(serializers.ModelSerializer):
    """
    Serializer API des opérations SPARK.

    La création produit toujours une opération EN_ATTENTE.

    Les règles fondamentales sont contrôlées à deux niveaux :
    - validation API pour fournir une erreur HTTP 400 propre ;
    - contraintes du modèle / PostgreSQL pour garantir l'intégrité
      des données même en dehors de l'API.
    """

    class Meta:
        model = Operation

        fields = (
            "id",
            "cycle",
            "recharge_cycle",
            "client",
            "date_operation",
            "type",
            "type_operation",
            "montant",
            "statut",
            "reference",
            "description",
            "moyen_paiement",
            "created_at",
            "updated_at",
        )

        read_only_fields = (
            "id",
            "client",
            "statut",
            "created_at",
            "updated_at",
        )

    def validate_montant(self, value):
        """
        Vérifie que le montant est strictement positif.
        """

        if value <= 0:
            raise serializers.ValidationError(
                "Le montant doit être strictement supérieur à 0."
            )

        return value

    def validate(self, attrs):
        """
        Validation globale de l'opération.

        Règles :
        - exactement un cycle OU une recharge ;
        - une cotisation doit être >= 1000 FCFA ;
        - le cycle/recharge doit appartenir au client connecté.
        """

        cycle = attrs.get("cycle")
        recharge_cycle = attrs.get("recharge_cycle")
        montant = attrs.get("montant")
        type_operation = attrs.get("type_operation")

        # ---------------------------------------------------------
        # 1. Destination XOR :
        # exactement une destination doit être fournie.
        # ---------------------------------------------------------

        if bool(cycle) == bool(recharge_cycle):
            raise serializers.ValidationError(
                "Une opération doit être liée à un cycle "
                "ou à une recharge, mais pas aux deux."
            )

        # ---------------------------------------------------------
        # 2. Minimum de cotisation
        # ---------------------------------------------------------

        if (
            type_operation == Operation.TYPE_COTISATION
            and montant is not None
            and montant < 1000
        ):
            raise serializers.ValidationError(
                {
                    "montant": (
                        "Une cotisation doit être d'un montant "
                        "minimum de 1000 FCFA."
                    )
                }
            )

        # ---------------------------------------------------------
        # 3. Vérification du propriétaire
        # ---------------------------------------------------------

        request = self.context.get("request")

        if request and request.user.is_authenticated:
            user = request.user

            if cycle and cycle.client_id != user.id:
                raise serializers.ValidationError(
                    "Ce cycle n'appartient pas à l'utilisateur connecté."
                )

            if (
                recharge_cycle
                and recharge_cycle.client_id != user.id
            ):
                raise serializers.ValidationError(
                    "Cette recharge n'appartient pas à l'utilisateur connecté."
                )

        return attrs

    def create(self, validated_data):
        """
        Crée l'opération pour l'utilisateur connecté.

        Le client ne peut pas choisir le champ client :
        celui-ci est toujours imposé par request.user.

        Le statut reste celui défini par le modèle :
        EN_ATTENTE.
        """

        request = self.context["request"]

        return Operation.objects.create(
            client=request.user,
            **validated_data,
        )
