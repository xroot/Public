from django.contrib.auth import authenticate
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from accounts.models import CustomUser


class LoginSerializer(serializers.Serializer):
    """
    Serializer pour le login (email ou phone + password)
    Retourne l'utilisateur authentifié avec ses données de profil
    """
    email_or_phone = serializers.CharField(
        write_only=True,
        help_text="Email ou numéro de téléphone"
    )
    password = serializers.CharField(
        write_only=True,
        style={'input_type': 'password'},
        help_text="Mot de passe"
    )
    
    # Champs de lecture (retour au login)
    id = serializers.IntegerField(read_only=True)
    email = serializers.EmailField(read_only=True)
    phone = serializers.CharField(read_only=True)
    first_name = serializers.CharField(read_only=True)
    last_name = serializers.CharField(read_only=True)
    
    def validate(self, attrs):
        """
        Valide les identifiants et retourne l'utilisateur authentifié
        """
        email_or_phone = attrs.get('email_or_phone')
        password = attrs.get('password')
        
        if not email_or_phone or not password:
            raise ValidationError({
                'email_or_phone': 'Email ou téléphone requis',
                'password': 'Mot de passe requis'
            })
        
        # Chercher par email d'abord
        user = None
        try:
            user = CustomUser.objects.get(email=email_or_phone)
        except CustomUser.DoesNotExist:
            # Chercher par téléphone
            try:
                user = CustomUser.objects.get(phone=email_or_phone)
            except CustomUser.DoesNotExist:
                raise ValidationError({
                    'email_or_phone': 'Aucun compte trouvé avec cet email ou téléphone'
                })
        
        # Vérifier le mot de passe
        if not user.check_password(password):
            raise ValidationError({
                'password': 'Mot de passe incorrect'
            })
        
        # Vérifier si le compte est actif
        if not user.is_active:
            raise ValidationError({
                'email_or_phone': 'Ce compte est désactivé'
            })
        
        attrs['user'] = user
        return attrs
    
    def to_representation(self, instance):
        """
        Retourne les données utilisateur au login
        """
        user = instance.get('user')
        if user:
            return {
                'id': user.id,
                'email': user.email,
                'phone': user.phone,
                'first_name': user.first_name,
                'last_name': user.last_name,
            }
        return {}


class CurrentUserSerializer(serializers.ModelSerializer):
    """
    Serializer pour afficher l'utilisateur courant (GET /api/me/)
    """
    class Meta:
        model = CustomUser
        fields = ['id', 'email', 'phone', 'first_name', 'last_name', 'is_active', 'is_staff']
        read_only_fields = ['id', 'email', 'phone', 'first_name', 'last_name', 'is_active', 'is_staff']
