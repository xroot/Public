# api/serializers/user.py
from rest_framework import serializers
from accounts.models import CustomUser


class UserSerializer(serializers.ModelSerializer):
    """
    Serializer public pour la lecture et la création
    d'utilisateurs SPARK.
    """

    password = serializers.CharField(
        write_only=True,
        required=True,
        min_length=8,
    )

    class Meta:
        model = CustomUser

        fields = (
            "id",
            "phone",
            "first_name",
            "last_name",
            "email",
            "password",
            "is_active",
            "date_joined",
        )

        read_only_fields = (
            "id",
            "is_active",
            "date_joined",
        )

    def create(self, validated_data):
        """
        Création sécurisée de l'utilisateur.

        Le mot de passe est hashé par Django via
        CustomUserManager.create_user().
        """

        password = validated_data.pop("password")

        return CustomUser.objects.create_user(

            password=password,
            **validated_data,
        )


class RegisterSerializer(serializers.ModelSerializer):
    """
    Serializer dédié à l'inscription publique SPARK.
    """

    password = serializers.CharField(
        write_only=True,
        required=True,
        min_length=8,
    )

    class Meta:
        model = CustomUser

        fields = (
            "id",
            "phone",
            "first_name",
            "last_name",
            "email",
            "password",
        )

        read_only_fields = (
            "id",
        )

    def create(self, validated_data):
        """
        Création sécurisée d'un nouvel utilisateur SPARK.
        """

        password = validated_data.pop("password")

        return CustomUser.objects.create_user(
            password=password,
            **validated_data,
        )