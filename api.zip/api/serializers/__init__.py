class CharField:
    pass


class ModelSerializer:
    pass