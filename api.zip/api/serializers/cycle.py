# api/serializers/cycle.py

from rest_framework import serializers

from cycles.models import Cycle


class CycleSerializer(serializers.ModelSerializer):
    """
    Serializer de lecture d'un cycle SPARK.

    Les données financières calculées proviennent
    directement du moteur métier de Cycle.
    """

    total_cotisations = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        read_only=True,
    )

    total_acquis = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        read_only=True,
    )

    solde_disponible = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        read_only=True,
    )

    reste_a_acquerir = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        read_only=True,
    )

    reste_a_atteindre = serializers.DecimalField(
        max_digits=15,
        decimal_places=2,
        read_only=True,
    )

    progression = serializers.DecimalField(
        max_digits=6,
        decimal_places=2,
        read_only=True,
    )

    objectif_atteint = serializers.SerializerMethodField()

    cycle_precedent_numero = serializers.SerializerMethodField()

    cycle_suivant_numero = serializers.SerializerMethodField()

    class Meta:
        model = Cycle

        fields = (
            "id",
            "numero",
            "client",
            "date_debut",
            "date_fin",
            "date_bouclage",
            "date_atteinte_objectif",
            "objectif",
            "montant_initial",
            "statut",
            "choix_client",
            "date_choix_client",
            "cycle_precedent",
            "cycle_precedent_numero",
            "montant_reporte",
            "date_report",
            "total_cotisations",
            "total_acquis",
            "solde_disponible",
            "reste_a_acquerir",
            "reste_a_atteindre",
            "progression",
            "objectif_atteint",
            "cycle_suivant_numero",
            "created_at",
            "updated_at",
        )

        read_only_fields = fields

    def get_objectif_atteint(self, obj):
        return obj.objectif_atteint()

    def get_cycle_precedent_numero(self, obj):
        if obj.cycle_precedent_id:
            return obj.cycle_precedent.numero

        return None

    def get_cycle_suivant_numero(self, obj):
        try:
            return obj.cycle_suivant.numero
        except Cycle.cycle_suivant.RelatedObjectDoesNotExist:
            return None


class CycleCreateSerializer(serializers.ModelSerializer):
    """
    Serializer d'écriture pour la création d'un cycle.

    Le client est toujours imposé par request.user.
    Les données calculées et les états métier restent contrôlés
    par le moteur Cycle.
    """

    class Meta:
        model = Cycle

        fields = (
            "numero",
            "date_debut",
            "date_fin",
            "objectif",
            "montant_initial",
            "cycle_precedent",
        )

    def create(self, validated_data):
        return Cycle.objects.create(
            client=self.context["request"].user,
            **validated_data,
        )


class CycleChoixSerializer(serializers.Serializer):
    """
    Serializer pour le choix du client après clôture
    d'un cycle incomplet.
    """

    choix = serializers.ChoiceField(
        choices=Cycle.CHOIX_CLIENT_CHOICES
    )


class CycleReporterSerializer(serializers.Serializer):
    """
    Serializer des paramètres facultatifs du report à nouveau.
    """

    date_debut = serializers.DateTimeField(
        required=False,
        allow_null=True,
    )

    date_fin = serializers.DateTimeField(
        required=False,
        allow_null=True,
    )