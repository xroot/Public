# api/serializers/history.py
from rest_framework import serializers


class HistoriqueEvenementSerializer(serializers.Serializer):
    """
    Représentation unifiée d'un événement de l'historique client.

    Ce n'est pas un ModelSerializer : l'historique combine plusieurs
    sources différentes (Operation liées à un Cycle, Operation liées à
    une Recharge, événements de report entre cycles) dans un flux
    chronologique unique, sans dupliquer les règles métier de ces
    modèles.
    """

    type_evenement = serializers.CharField()
    date = serializers.DateTimeField()
    origine = serializers.CharField()  # "CYCLE" / "RECHARGE" / "REPORT"
    cycle_numero = serializers.CharField(allow_null=True)
    montant = serializers.DecimalField(max_digits=15, decimal_places=2)
    statut = serializers.CharField(allow_null=True)
    reference = serializers.CharField(allow_null=True)
    description = serializers.CharField(allow_null=True, allow_blank=True)
