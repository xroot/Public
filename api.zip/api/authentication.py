# api/authentication.py

from rest_framework.authentication import SessionAuthentication


class SparkSessionAuthentication(SessionAuthentication):
    """
    Authentification utilisée par l'API SPARK.

    Pour les endpoints métier, une requête non authentifiée
    doit produire HTTP 403.
    """
    pass


class SparkAuthSessionAuthentication(SessionAuthentication):
    """
    Authentification utilisée par les endpoints d'authentification.

    Ces endpoints doivent retourner HTTP 401 lorsqu'un utilisateur
    n'est pas authentifié.
    """

    def authenticate_header(self, request):
        return "Session"