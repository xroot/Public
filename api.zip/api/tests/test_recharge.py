# api/tests/test_recharge.py
from decimal import Decimal

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import CustomUser
from cycles.models import Cycle, Operation, RechargeCycle


def creer_cycle(client, numero, statut=Cycle.STATUT_COMPLETED, **kwargs):
    maintenant = timezone.now()
    defaults = dict(
        numero=numero,
        client=client,
        date_debut=maintenant,
        date_fin=maintenant + timezone.timedelta(days=30),
        montant_initial=Decimal("5000.00"),
        objectif=Decimal("28500.00"),
        statut=statut,
    )
    defaults.update(kwargs)
    return Cycle.objects.create(**defaults)


def creer_recharge(client, cycle, statut=RechargeCycle.STATUT_ACTIVE, **kwargs):
    defaults = dict(
        client=client,
        cycle=cycle,
        cycle_origine=cycle,
        montant_initial=Decimal("0.00"),
        solde=Decimal("0.00"),
        statut=statut,
    )
    defaults.update(kwargs)
    return RechargeCycle.objects.create(**defaults)


class RechargeListAPITest(APITestCase):
    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000070", password="testpass123",
            first_name="Alice", last_name="Test",
        )
        self.bob = CustomUser.objects.create_user(
            phone="690000071", password="testpass123",
            first_name="Bob", last_name="Test",
        )

        self.cycle_alice = creer_cycle(self.alice, "C-RECH-ALICE-1")
        self.cycle_bob = creer_cycle(self.bob, "C-RECH-BOB-1")

        self.recharge_alice = creer_recharge(self.alice, self.cycle_alice)
        self.recharge_bob = creer_recharge(self.bob, self.cycle_bob)

    def test_liste_necessite_authentification(self):
        response = self.client.get(reverse("recharges"))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_liste_isolee_par_client(self):
        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("recharges"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ids = [r["id"] for r in response.data]
        self.assertIn(self.recharge_alice.id, ids)
        self.assertNotIn(self.recharge_bob.id, ids)

    def test_detail_recharge_dun_autre_client_est_404(self):
        self.client.force_authenticate(user=self.alice)
        url = reverse("recharge-detail", args=[self.recharge_bob.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_recharge_inexistante_renvoie_404(self):
        self.client.force_authenticate(user=self.alice)
        url = reverse("recharge-detail", args=[999999])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class RechargeProgressionAPITest(APITestCase):
    """
    Vérifie que l'API expose fidèlement les calculs du moteur métier
    RechargeCycle (objectif officiel 6 500 FCFA).
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000080", password="testpass123",
            first_name="Alice", last_name="Test",
        )
        self.cycle = creer_cycle(self.alice, "C-RECH-PROG-1")
        self.recharge = creer_recharge(self.alice, self.cycle)

        # 2 opérations validées de 2000 chacune = 4000.
        Operation.objects.create(
            client=self.alice, recharge_cycle=self.recharge,
            montant=Decimal("2000.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="RECH-OP-001",
        )
        Operation.objects.create(
            client=self.alice, recharge_cycle=self.recharge,
            montant=Decimal("2000.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="RECH-OP-002",
        )
        # Une opération en attente ne doit pas compter.
        Operation.objects.create(
            client=self.alice, recharge_cycle=self.recharge,
            montant=Decimal("5000.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_EN_ATTENTE, reference="RECH-OP-003",
        )

        self.client.force_authenticate(user=self.alice)

    def test_objectif_par_defaut_est_6500(self):
        url = reverse("recharge-detail", args=[self.recharge.id])
        response = self.client.get(url)
        self.assertEqual(Decimal(response.data["objectif"]), Decimal("6500.00"))

    def test_total_acquis_ignore_les_operations_non_validees(self):
        url = reverse("recharge-detail", args=[self.recharge.id])
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Decimal(response.data["total_acquis"]), Decimal("4000.00"))
        self.assertFalse(response.data["objectif_atteint"])

    def test_objectif_atteint_quand_le_solde_couvre_6500(self):
        Operation.objects.create(
            client=self.alice, recharge_cycle=self.recharge,
            montant=Decimal("2500.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="RECH-OP-004",
        )
        url = reverse("recharge-detail", args=[self.recharge.id])
        response = self.client.get(url)
        self.assertTrue(response.data["objectif_atteint"])

    def test_cycle_origine_expose_par_numero(self):
        url = reverse("recharge-detail", args=[self.recharge.id])
        response = self.client.get(url)
        self.assertEqual(response.data["cycle_origine_numero"], "C-RECH-PROG-1")

class RechargeActionsAPITest(APITestCase):
    """
    Vérifie les actions HTTP de RechargeCycle.

    Les règles métier restent dans RechargeCycle.activer()
    et RechargeCycle.cloturer().
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000110",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )

        self.cycle = creer_cycle(
            self.alice,
            "C-RECH-ACTIONS",
            statut=Cycle.STATUT_COMPLETED,
        )

        self.client.force_authenticate(user=self.alice)

    def test_activer_une_recharge(self):
        recharge = creer_recharge(
            self.alice,
            self.cycle,
            statut=RechargeCycle.STATUT_DRAFT,
        )

        url = reverse("recharge-activer", args=[recharge.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        recharge.refresh_from_db()
        self.assertEqual(
            recharge.statut,
            RechargeCycle.STATUT_ACTIVE,
        )

    def test_activer_une_recharge_deja_active_est_rejete(self):
        recharge = creer_recharge(
            self.alice,
            self.cycle,
            statut=RechargeCycle.STATUT_ACTIVE,
        )

        url = reverse("recharge-activer", args=[recharge.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        recharge.refresh_from_db()
        self.assertEqual(
            recharge.statut,
            RechargeCycle.STATUT_ACTIVE,
        )

    def test_cloturer_recharge_ayant_atteint_objectif(self):
        recharge = creer_recharge(
            self.alice,
            self.cycle,
            statut=RechargeCycle.STATUT_ACTIVE,
            montant_initial=Decimal("6500.00"),
            solde=Decimal("6500.00"),
        )

        url = reverse("recharge-cloturer", args=[recharge.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        recharge.refresh_from_db()
        self.assertEqual(
            recharge.statut,
            RechargeCycle.STATUT_COMPLETED,
        )
        self.assertIsNotNone(recharge.date_cloture)

    def test_cloturer_recharge_incomplete_devient_expired(self):
        recharge = creer_recharge(
            self.alice,
            self.cycle,
            statut=RechargeCycle.STATUT_ACTIVE,
            montant_initial=Decimal("2000.00"),
            solde=Decimal("2000.00"),
        )

        url = reverse("recharge-cloturer", args=[recharge.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        recharge.refresh_from_db()
        self.assertEqual(
            recharge.statut,
            RechargeCycle.STATUT_EXPIRED,
        )
        self.assertIsNotNone(recharge.date_cloture)