# api/tests/test_users.py

from django.contrib.auth.models import Group, Permission
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from accounts.models import CustomUser


class UserAPITest(APITestCase):
    """
    Tests de sécurité et d'accès des endpoints utilisateurs SPARK.

    Le RBAC API s'appuie sur les permissions Django existantes :
        - accounts.view_customuser
        - accounts.add_customuser

    Aucun rôle métier n'est recréé ici.
    """

    def setUp(self):
        self.client_user = CustomUser.objects.create_user(
            phone="690001001",
            password="testpass123",
            first_name="Client",
            last_name="SPARK",
        )

        self.consultant = CustomUser.objects.create_user(
            phone="690001002",
            password="testpass123",
            first_name="Consultant",
            last_name="SPARK",
        )

        self.responsable = CustomUser.objects.create_user(
            phone="690001003",
            password="testpass123",
            first_name="Responsable",
            last_name="SPARK",
        )

        self.superuser = CustomUser.objects.create_superuser(
            phone="690001004",
            password="testpass123",
            first_name="Super",
            last_name="User",
        )

        self._ajouter_permission(
            self.consultant,
            "view_customuser",
        )

        self._ajouter_permission(
            self.responsable,
            "view_customuser",
        )

    @staticmethod
    def _ajouter_permission(user, codename):
        """
        Ajoute une permission Django à l'utilisateur via son groupe.

        Le test reproduit le RBAC existant sans modifier les modèles
        ni les permissions de production.
        """

        permission = Permission.objects.get(
            content_type__app_label="accounts",
            codename=codename,
        )

        group_name = f"Test_{codename}_{user.phone}"

        group = Group.objects.create(name=group_name)
        group.permissions.add(permission)

        user.groups.add(group)

    # ------------------------------------------------------------------
    # GET /api/users/
    # ------------------------------------------------------------------

    def test_liste_utilisateurs_necessite_authentification(self):
        response = self.client.get(reverse("user-list"))

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_client_ne_peut_pas_lister_les_utilisateurs(self):
        self.client.force_authenticate(user=self.client_user)

        response = self.client.get(reverse("user-list"))

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_consultant_peut_lister_les_utilisateurs(self):
        self.client.force_authenticate(user=self.consultant)

        response = self.client.get(reverse("user-list"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertGreaterEqual(len(response.data), 4)

    def test_responsable_peut_lister_les_utilisateurs(self):
        self.client.force_authenticate(user=self.responsable)

        response = self.client.get(reverse("user-list"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

    def test_superuser_peut_lister_les_utilisateurs(self):
        self.client.force_authenticate(user=self.superuser)

        response = self.client.get(reverse("user-list"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

    # ------------------------------------------------------------------
    # POST /api/users/
    # ------------------------------------------------------------------

    def test_client_ne_peut_pas_creer_un_utilisateur(self):
        self.client.force_authenticate(user=self.client_user)

        response = self.client.post(
            reverse("user-list"),
            {
                "phone": "690001010",
                "first_name": "Nouveau",
                "last_name": "Client",
                "email": "nouveau@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_consultant_ne_peut_pas_creer_un_utilisateur(self):
        self.client.force_authenticate(user=self.consultant)

        response = self.client.post(
            reverse("user-list"),
            {
                "phone": "690001011",
                "first_name": "Nouveau",
                "last_name": "Consultant",
                "email": "nouveau.consultant@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_responsable_ne_peut_pas_creer_un_utilisateur_sans_permission_add(self):
        """
        Le groupe Responsable actuel possède view_customuser/change_customuser
        mais pas add_customuser.

        Le test verrouille donc le RBAC actuellement défini.
        """

        self.client.force_authenticate(user=self.responsable)

        response = self.client.post(
            reverse("user-list"),
            {
                "phone": "690001012",
                "first_name": "Nouveau",
                "last_name": "Responsable",
                "email": "nouveau.responsable@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_superuser_peut_creer_un_utilisateur(self):
        self.client.force_authenticate(user=self.superuser)

        response = self.client.post(
            reverse("user-list"),
            {
                "phone": "690001013",
                "first_name": "Nouveau",
                "last_name": "Utilisateur",
                "email": "nouveau.utilisateur@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        self.assertTrue(
            CustomUser.objects.filter(
                phone="690001013",
            ).exists()
        )

    # ------------------------------------------------------------------
    # GET /api/users/me/
    # ------------------------------------------------------------------

    def test_client_peut_consulter_son_propre_profil(self):
        self.client.force_authenticate(user=self.client_user)

        response = self.client.get(reverse("user-current"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            response.data["id"],
            self.client_user.id,
        )

        self.assertEqual(
            response.data["phone"],
            self.client_user.phone,
        )

    def test_consultant_peut_consulter_son_propre_profil(self):
        self.client.force_authenticate(user=self.consultant)

        response = self.client.get(reverse("user-current"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        self.assertEqual(
            response.data["id"],
            self.consultant.id,
        )

    def test_anonyme_ne_peut_pas_consulter_son_profil(self):
        response = self.client.get(reverse("user-current"))

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    # ------------------------------------------------------------------
    # POST /api/register/
    # ------------------------------------------------------------------

    def test_inscription_publique_reste_accessible_sans_authentification(self):
        response = self.client.post(
            reverse("register"),
            {
                "phone": "690001014",
                "first_name": "Inscrit",
                "last_name": "Public",
                "email": "inscription@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        self.assertTrue(
            CustomUser.objects.filter(
                phone="690001014",
            ).exists()
        )

    def test_mot_de_passe_nest_pas_retourne_apres_inscription(self):
        response = self.client.post(
            reverse("register"),
            {
                "phone": "690001015",
                "first_name": "Test",
                "last_name": "Password",
                "email": "password@example.com",
                "password": "testpass123",
            },
            format="json",
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        self.assertNotIn(
            "password",
            response.data,
        )
