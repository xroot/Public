# api/tests/test_cycles.py
from decimal import Decimal

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import CustomUser
from cycles.models import Cycle, Operation


def creer_cycle(client, numero, statut=Cycle.STATUT_ACTIVE, **kwargs):
    maintenant = timezone.now()
    defaults = dict(
        numero=numero,
        client=client,
        date_debut=maintenant,
        date_fin=maintenant + timezone.timedelta(days=30),
        montant_initial=Decimal("5000.00"),
        objectif=Decimal("28500.00"),
        statut=statut,
    )
    defaults.update(kwargs)
    return Cycle.objects.create(**defaults)


def creer_operation_validee(client, cycle, montant, reference,
                            type_operation=Operation.TYPE_COTISATION):
    return Operation.objects.create(
        client=client,
        cycle=cycle,
        montant=Decimal(montant),
        type_operation=type_operation,
        statut=Operation.STATUT_VALIDEE,
        reference=reference,
    )


class CycleListAPITest(APITestCase):
    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000010", password="testpass123",
            first_name="Alice", last_name="Test",
        )
        self.bob = CustomUser.objects.create_user(
            phone="690000011", password="testpass123",
            first_name="Bob", last_name="Test",
        )

        self.cycle_alice = creer_cycle(self.alice, "C-ALICE-1")
        self.cycle_bob = creer_cycle(self.bob, "C-BOB-1")

    def test_liste_necessite_authentification(self):
        response = self.client.get(reverse("cycles"))
        # SessionAuthentication seule -> pas de challenge -> 403, pas 401.
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_liste_isolee_par_client(self):
        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("cycles"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        numeros = [c["numero"] for c in response.data]
        self.assertIn(self.cycle_alice.numero, numeros)
        self.assertNotIn(self.cycle_bob.numero, numeros)

    def test_detail_cycle_dun_autre_client_est_404(self):
        self.client.force_authenticate(user=self.alice)
        url = reverse("cycle-detail", args=[self.cycle_bob.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_cycle_inexistant_renvoie_404(self):
        self.client.force_authenticate(user=self.alice)
        url = reverse("cycle-detail", args=[999999])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

class CycleProgressionAPITest(APITestCase):
    """
    Vérifie que l'API expose fidèlement les calculs du moteur métier
    (Cycle.total_acquis / progression / solde_disponible), sans les
    recalculer côté API.
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000020", password="testpass123",
            first_name="Alice", last_name="Test",
        )
        self.cycle = creer_cycle(self.alice, "C-PROGRESSION-1")

        # Montant initial 5000 + deux cotisations validées = 15000.
        creer_operation_validee(self.alice, self.cycle, "5000.00", "REF-001")
        creer_operation_validee(self.alice, self.cycle, "5000.00", "REF-002")

        # Une opération EN_ATTENTE ne doit pas compter dans la progression.
        Operation.objects.create(
            client=self.alice,
            cycle=self.cycle,
            montant=Decimal("10000.00"),
            type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_EN_ATTENTE,
            reference="REF-003-EN-ATTENTE",
        )

        self.client.force_authenticate(user=self.alice)

    def test_total_acquis_ignore_les_operations_non_validees(self):
        url = reverse("cycle-detail", args=[self.cycle.id])
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # montant_initial (5000) + 2 cotisations validées (5000 + 5000) = 15000
        self.assertEqual(Decimal(response.data["total_acquis"]), Decimal("15000.00"))
        self.assertEqual(
            Decimal(response.data["solde_disponible"]), Decimal("15000.00")
        )

    def test_progression_calculee_sur_lobjectif(self):
        url = reverse("cycle-detail", args=[self.cycle.id])
        response = self.client.get(url)

        # 15000 / 28500 * 100 ≈ 52.63
        progression = Decimal(response.data["progression"])
        self.assertAlmostEqual(float(progression), 52.63, places=1)
        self.assertFalse(response.data["objectif_atteint"])

    def test_objectif_atteint_bascule_a_true_quand_le_cumul_est_suffisant(self):
        # 15000 déjà acquis + 15000 -> dépasse largement 28500.
        creer_operation_validee(self.alice, self.cycle, "15000.00", "REF-004")

        url = reverse("cycle-detail", args=[self.cycle.id])
        response = self.client.get(url)

        self.assertTrue(response.data["objectif_atteint"])


class CycleReportAPITest(APITestCase):
    """
    Vérifie que la relation cycle_precedent / cycle_suivant est bien
    exposée par l'API dans les deux sens.
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000030", password="testpass123",
            first_name="Alice", last_name="Test",
        )

        self.cycle_1 = creer_cycle(
            self.alice, "C-REPORT-1", statut=Cycle.STATUT_INCOMPLET,
        )
        self.cycle_2 = creer_cycle(
            self.alice, "C-REPORT-2", statut=Cycle.STATUT_DRAFT,
            cycle_precedent=self.cycle_1,
        )

        self.client.force_authenticate(user=self.alice)

    def test_cycle_precedent_expose_dans_le_detail_du_cycle_suivant(self):
        url = reverse("cycle-detail", args=[self.cycle_2.id])
        response = self.client.get(url)

        self.assertEqual(response.data["cycle_precedent_numero"], "C-REPORT-1")

    def test_cycle_suivant_expose_dans_le_detail_du_cycle_precedent(self):
        url = reverse("cycle-detail", args=[self.cycle_1.id])
        response = self.client.get(url)

        self.assertEqual(response.data["cycle_suivant_numero"], "C-REPORT-2")

    def test_cycle_suivant_absent_quand_pas_encore_reporte(self):
        url = reverse("cycle-detail", args=[self.cycle_2.id])
        response = self.client.get(url)

        self.assertIsNone(response.data["cycle_suivant_numero"])


class CycleActionsAPITest(APITestCase):
    """
    Vérifie les actions HTTP de Cycle.

    L'API délègue les règles métier aux méthodes de Cycle :
    activer(), cloturer(), enregistrer_choix_client()
    et reporter_vers_nouveau_cycle().
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000090",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )
        self.client.force_authenticate(user=self.alice)

    def test_activer_un_cycle(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-ACTIVER",
            statut=Cycle.STATUT_DRAFT,
        )

        url = reverse("cycle-activer", args=[cycle.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        cycle.refresh_from_db()
        self.assertEqual(cycle.statut, Cycle.STATUT_ACTIVE)

    def test_activer_un_cycle_deja_actif_est_rejete(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-ACTIVER-2",
            statut=Cycle.STATUT_ACTIVE,
        )

        url = reverse("cycle-activer", args=[cycle.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        cycle.refresh_from_db()
        self.assertEqual(cycle.statut, Cycle.STATUT_ACTIVE)

    def test_cloturer_un_cycle_actif_incomplet(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-CLOTURE",
            statut=Cycle.STATUT_ACTIVE,
            objectif=Decimal("28500.00"),
            montant_initial=Decimal("5000.00"),
        )

        url = reverse("cycle-cloturer", args=[cycle.id])
        response = self.client.post(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        cycle.refresh_from_db()
        self.assertEqual(cycle.statut, Cycle.STATUT_INCOMPLET)
        self.assertIsNotNone(cycle.date_bouclage)

    def test_choix_reporter_sur_cycle_incomplet(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-CHOIX",
            statut=Cycle.STATUT_INCOMPLET,
        )

        url = reverse("cycle-choix", args=[cycle.id])
        response = self.client.post(
            url,
            {"choix": Cycle.CHOIX_REPORTER},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        cycle.refresh_from_db()
        self.assertEqual(cycle.choix_client, Cycle.CHOIX_REPORTER)
        self.assertIsNotNone(cycle.date_choix_client)

    def test_choix_invalide_est_rejete(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-CHOIX-2",
            statut=Cycle.STATUT_INCOMPLET,
        )

        url = reverse("cycle-choix", args=[cycle.id])
        response = self.client.post(
            url,
            {"choix": "CHOIX_INVALIDE"},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_reporter_cree_un_nouveau_cycle(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-REPORT",
            statut=Cycle.STATUT_INCOMPLET,
        )

        cycle.choix_client = Cycle.CHOIX_REPORTER
        cycle.save(update_fields=["choix_client"])

        # Le solde disponible à reporter = montant_initial.
        cycle.solde = Decimal("5000.00")
        cycle.save(update_fields=["solde"])

        url = reverse("cycle-reporter", args=[cycle.id])
        response = self.client.post(url, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        cycle.refresh_from_db()

        self.assertIsNotNone(cycle.cycle_suivant)
        self.assertEqual(
            cycle.cycle_suivant.montant_initial,
            Decimal("5000.00"),
        )
        self.assertEqual(
            cycle.cycle_suivant.statut,
            Cycle.STATUT_DRAFT,
        )

    def test_reporter_sans_choix_est_rejete(self):
        cycle = creer_cycle(
            self.alice,
            "C-ACTION-REPORT-2",
            statut=Cycle.STATUT_INCOMPLET,
        )

        url = reverse("cycle-reporter", args=[cycle.id])
        response = self.client.post(url, format="json")

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
