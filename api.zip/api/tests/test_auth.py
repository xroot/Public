from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from accounts.models import CustomUser


class AuthenticationTestCase(TestCase):
    """
    Tests pour l'authentification API (15.12)
    """
    
    def setUp(self):
        self.client = APIClient()
        # Créer un utilisateur de test
        self.user = CustomUser.objects.create_user(
            email='test@example.com',
            phone='237123456789',
            password='testpass123',
            first_name='Test',
            last_name='User'
        )
    
    # ========== Tests Login ==========
    
    def test_login_with_email_valid(self):
        """
        Test login avec email valide
        POST /api/login/ → 200 OK + user data
        """
        response = self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('user', response.data)
        self.assertEqual(response.data['user']['email'], 'test@example.com')
        self.assertEqual(response.data['user']['phone'], '237123456789')
    
    def test_login_with_phone_valid(self):
        """
        Test login avec téléphone valide
        POST /api/login/ → 200 OK + user data
        """
        response = self.client.post('/api/login/', {
            'email_or_phone': '237123456789',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('user', response.data)
        self.assertEqual(response.data['user']['email'], 'test@example.com')
    
    def test_login_wrong_password(self):
        """
        Test login avec mauvais mot de passe
        POST /api/login/ → 400 Bad Request
        """
        response = self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com',
            'password': 'wrongpassword'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('password', response.data['errors'])
    
    def test_login_nonexistent_user(self):
        """
        Test login avec email/phone inexistant
        POST /api/login/ → 400 Bad Request
        """
        response = self.client.post('/api/login/', {
            'email_or_phone': 'nonexistent@example.com',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email_or_phone', response.data['errors'])
    
    def test_login_inactive_user(self):
        """
        Test login avec compte désactivé
        POST /api/login/ → 400 Bad Request
        """
        self.user.is_active = False
        self.user.save()
        response = self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com',
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email_or_phone', response.data['errors'])
    
    def test_login_missing_email(self):
        """
        Test login sans email/phone
        POST /api/login/ → 400 Bad Request
        """
        response = self.client.post('/api/login/', {
            'password': 'testpass123'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email_or_phone', response.data['errors'])
    
    def test_login_missing_password(self):
        """
        Test login sans mot de passe
        POST /api/login/ → 400 Bad Request
        """
        response = self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('password', response.data['errors'])
    
    # ========== Tests Current User (GET /api/me/) ==========
    
    def test_current_user_authenticated(self):
        """
        Test GET /api/me/ avec utilisateur authentifié
        GET /api/me/ → 200 OK + user data
        """
        # Login d'abord
        self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com',
            'password': 'testpass123'
        })
        # Puis appel GET /api/me/
        response = self.client.get('/api/me/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['email'], 'test@example.com')
        self.assertEqual(response.data['phone'], '237123456789')
        self.assertEqual(response.data['first_name'], 'Test')
        self.assertEqual(response.data['last_name'], 'User')
    
    def test_current_user_unauthenticated(self):
        """
        Test GET /api/me/ sans authentification
        GET /api/me/ → 401 Unauthorized
        """
        response = self.client.get('/api/me/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    
    # ========== Tests Logout ==========
    
    def test_logout_authenticated(self):
        """
        Test logout avec utilisateur authentifié
        POST /api/logout/ → 200 OK
        """
        # Login d'abord
        self.client.post('/api/login/', {
            'email_or_phone': 'test@example.com',
            'password': 'testpass123'
        })
        # Puis logout
        response = self.client.post('/api/logout/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('message', response.data)
        
        # Vérifier que GET /api/me/ retourne 401 après logout
        response_after = self.client.get('/api/me/')
        self.assertEqual(response_after.status_code, status.HTTP_401_UNAUTHORIZED)
    
    def test_logout_unauthenticated(self):
        """
        Test logout sans authentification
        POST /api/logout/ → 401 Unauthorized
        """
        response = self.client.post('/api/logout/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
