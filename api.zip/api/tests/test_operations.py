# api/tests/test_operations.py

from decimal import Decimal

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import CustomUser
from cycles.models import Cycle, Operation


def creer_cycle(client, numero, statut=Cycle.STATUT_ACTIVE, **kwargs):
    maintenant = timezone.now()

    defaults = dict(
        numero=numero,
        client=client,
        date_debut=maintenant,
        date_fin=maintenant + timezone.timedelta(days=30),
        montant_initial=Decimal("5000.00"),
        objectif=Decimal("28500.00"),
        statut=statut,
    )

    defaults.update(kwargs)

    return Cycle.objects.create(**defaults)


class OperationListAPITest(APITestCase):
    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000040",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )

        self.bob = CustomUser.objects.create_user(
            phone="690000041",
            password="testpass123",
            first_name="Bob",
            last_name="Test",
        )

        self.cycle_alice = creer_cycle(
            self.alice,
            "C-OP-ALICE-1",
        )

        self.cycle_bob = creer_cycle(
            self.bob,
            "C-OP-BOB-1",
        )

        self.operation_alice = Operation.objects.create(
            client=self.alice,
            cycle=self.cycle_alice,
            montant=Decimal("2000.00"),
            type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE,
            reference="OP-ALICE-001",
        )

        self.operation_bob = Operation.objects.create(
            client=self.bob,
            cycle=self.cycle_bob,
            montant=Decimal("2000.00"),
            type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE,
            reference="OP-BOB-001",
        )

    def test_liste_necessite_authentification(self):
        response = self.client.get(reverse("operations"))

        self.assertEqual(
            response.status_code,
            status.HTTP_403_FORBIDDEN,
        )

    def test_liste_isolee_par_client(self):
        self.client.force_authenticate(user=self.alice)

        response = self.client.get(reverse("operations"))

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        references = [o["reference"] for o in response.data]

        self.assertIn(
            "OP-ALICE-001",
            references,
        )

        self.assertNotIn(
            "OP-BOB-001",
            references,
        )

    def test_detail_operation_dun_autre_client_est_404(self):
        self.client.force_authenticate(user=self.alice)

        url = reverse(
            "operation-detail",
            args=[self.operation_bob.id],
        )

        response = self.client.get(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_404_NOT_FOUND,
        )


class OperationCreationAPITest(APITestCase):
    """
    Vérifie la création des opérations via l'API.

    La création produit toujours une opération EN_ATTENTE.
    Les règles de sécurité et de validation sont appliquées
    avant l'enregistrement lorsque cela est possible.
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000050",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )

        self.bob = CustomUser.objects.create_user(
            phone="690000051",
            password="testpass123",
            first_name="Bob",
            last_name="Test",
        )

        self.cycle_alice = creer_cycle(
            self.alice,
            "C-CREATE-ALICE-1",
        )

        self.cycle_bob = creer_cycle(
            self.bob,
            "C-CREATE-BOB-1",
        )

        self.client.force_authenticate(
            user=self.alice,
        )

    def test_creation_operation_sur_son_propre_cycle(self):
        payload = {
            "cycle": self.cycle_alice.id,
            "montant": "2000.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-CREATE-001",
            "moyen_paiement": "ESPECES",
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        operation = Operation.objects.get(
            reference="OP-CREATE-001",
        )

        self.assertEqual(
            operation.client_id,
            self.alice.id,
        )

        # Le statut ne peut pas être choisi par le client.
        # Toute nouvelle opération est EN_ATTENTE.
        self.assertEqual(
            operation.statut,
            Operation.STATUT_EN_ATTENTE,
        )

    def test_creation_operation_sans_cycle_ni_recharge_est_rejetee(self):
        payload = {
            "montant": "2000.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-CREATE-002",
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

        self.assertFalse(
            Operation.objects.filter(
                reference="OP-CREATE-002",
            ).exists()
        )

    def test_creation_operation_sur_le_cycle_dun_autre_client_est_rejetee(
        self,
    ):
        payload = {
            "cycle": self.cycle_bob.id,
            "montant": "2000.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-CREATE-003",
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

        self.assertFalse(
            Operation.objects.filter(
                reference="OP-CREATE-003",
            ).exists()
        )

    def test_client_ne_peut_pas_forcer_le_statut_a_la_creation(self):
        payload = {
            "cycle": self.cycle_alice.id,
            "montant": "2000.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-CREATE-004",
            "statut": Operation.STATUT_VALIDEE,
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_201_CREATED,
        )

        operation = Operation.objects.get(
            reference="OP-CREATE-004",
        )

        self.assertEqual(
            operation.statut,
            Operation.STATUT_EN_ATTENTE,
        )

    def test_creation_operation_sous_le_minimum_est_rejetee(self):
        payload = {
            "cycle": self.cycle_alice.id,
            "montant": "500.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-CREATE-MINIMUM",
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

        self.assertFalse(
            Operation.objects.filter(
                reference="OP-CREATE-MINIMUM",
            ).exists()
        )


class OperationValidationMetierAPITest(APITestCase):
    """
    Vérifie que les règles métier sont respectées.

    Une opération COTISATION inférieure à 1000 FCFA ne peut
    plus être créée : la règle est garantie par le serializer
    et par la contrainte d'intégrité PostgreSQL.
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000060",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )

        self.cycle = creer_cycle(
            self.alice,
            "C-VALID-ALICE-1",
        )

    def test_creation_operation_sous_le_minimum_est_rejetee(self):
        self.client.force_authenticate(
            user=self.alice,
        )

        payload = {
            "cycle": self.cycle.id,
            "montant": "500.00",
            "type_operation": Operation.TYPE_COTISATION,
            "reference": "OP-MIN-001",
        }

        response = self.client.post(
            reverse("operations"),
            payload,
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )

        self.assertFalse(
            Operation.objects.filter(
                reference="OP-MIN-001",
            ).exists()
        )


class OperationActionsAPITest(APITestCase):
    """
    Vérifie les endpoints HTTP d'action sur Operation.

    L'API délègue les règles métier à :
    Operation.valider(),
    Operation.rejeter()
    et Operation.annuler().
    """

    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000100",
            password="testpass123",
            first_name="Alice",
            last_name="Test",
        )

        self.cycle = creer_cycle(
            self.alice,
            "C-OP-ACTIONS",
            statut=Cycle.STATUT_ACTIVE,
        )

        self.client.force_authenticate(
            user=self.alice,
        )

    def creer_operation(
        self,
        reference,
        montant="2000.00",
    ):
        return Operation.objects.create(
            client=self.alice,
            cycle=self.cycle,
            montant=Decimal(montant),
            type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_EN_ATTENTE,
            reference=reference,
        )

    def test_valider_operation(self):
        operation = self.creer_operation(
            "OP-ACTION-VALIDE",
        )

        url = reverse(
            "operation-valider",
            args=[operation.id],
        )

        response = self.client.post(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        operation.refresh_from_db()

        self.assertEqual(
            operation.statut,
            Operation.STATUT_VALIDEE,
        )

    def test_rejeter_operation(self):
        operation = self.creer_operation(
            "OP-ACTION-REJET",
        )

        url = reverse(
            "operation-rejeter",
            args=[operation.id],
        )

        response = self.client.post(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        operation.refresh_from_db()

        self.assertEqual(
            operation.statut,
            Operation.STATUT_REJETEE,
        )

    def test_annuler_operation(self):
        operation = self.creer_operation(
            "OP-ACTION-ANNULATION",
        )

        url = reverse(
            "operation-annuler",
            args=[operation.id],
        )

        response = self.client.post(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        operation.refresh_from_db()

        self.assertEqual(
            operation.statut,
            Operation.STATUT_ANNULEE,
        )

    def test_operation_deja_validee_ne_peut_pas_etre_rejetee(self):
        operation = self.creer_operation(
            "OP-ACTION-DEJA-VALIDEE",
        )

        operation.statut = Operation.STATUT_VALIDEE

        operation.save(
            update_fields=["statut"],
        )

        url = reverse(
            "operation-rejeter",
            args=[operation.id],
        )

        response = self.client.post(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )