# api/tests/test_history.py
from decimal import Decimal

from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from accounts.models import CustomUser
from cycles.models import Cycle, Operation, RechargeCycle


def creer_cycle(client, numero, statut=Cycle.STATUT_ACTIVE, **kwargs):
    maintenant = timezone.now()
    defaults = dict(
        numero=numero,
        client=client,
        date_debut=maintenant,
        date_fin=maintenant + timezone.timedelta(days=30),
        montant_initial=Decimal("5000.00"),
        objectif=Decimal("28500.00"),
        statut=statut,
    )
    defaults.update(kwargs)
    return Cycle.objects.create(**defaults)


class HistoriqueAPITest(APITestCase):
    def setUp(self):
        self.alice = CustomUser.objects.create_user(
            phone="690000090", password="testpass123",
            first_name="Alice", last_name="Test",
        )
        self.bob = CustomUser.objects.create_user(
            phone="690000091", password="testpass123",
            first_name="Bob", last_name="Test",
        )

        self.cycle_alice = creer_cycle(self.alice, "C-HIST-ALICE-1")
        self.cycle_bob = creer_cycle(self.bob, "C-HIST-BOB-1")

        self.recharge_alice = RechargeCycle.objects.create(
            client=self.alice,
            cycle=self.cycle_alice,
            cycle_origine=self.cycle_alice,
            statut=RechargeCycle.STATUT_ACTIVE,
        )

        # Opération liée au cycle principal d'Alice.
        Operation.objects.create(
            client=self.alice, cycle=self.cycle_alice,
            montant=Decimal("2000.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="HIST-CYCLE-001",
        )
        # Opération liée à la Recharge d'Alice.
        Operation.objects.create(
            client=self.alice, recharge_cycle=self.recharge_alice,
            montant=Decimal("1500.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="HIST-RECH-001",
        )
        # Opération de Bob : ne doit jamais apparaître pour Alice.
        Operation.objects.create(
            client=self.bob, cycle=self.cycle_bob,
            montant=Decimal("2000.00"), type_operation=Operation.TYPE_COTISATION,
            statut=Operation.STATUT_VALIDEE, reference="HIST-BOB-001",
        )

    def test_necessite_authentification(self):
        response = self.client.get(reverse("historique"))
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_isole_par_client(self):
        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("historique"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        references = [e["reference"] for e in response.data["results"]]
        self.assertIn("HIST-CYCLE-001", references)
        self.assertIn("HIST-RECH-001", references)
        self.assertNotIn("HIST-BOB-001", references)

    def test_distingue_origine_cycle_et_recharge(self):
        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("historique"))

        par_reference = {
            e["reference"]: e for e in response.data["results"]
        }
        self.assertEqual(par_reference["HIST-CYCLE-001"]["origine"], "CYCLE")
        self.assertEqual(par_reference["HIST-RECH-001"]["origine"], "RECHARGE")

    def test_evenement_de_report_apparait_dans_lhistorique(self):
        cycle_suivant = creer_cycle(
            self.alice, "C-HIST-ALICE-2", statut=Cycle.STATUT_DRAFT,
            cycle_precedent=self.cycle_alice,
            montant_reporte=Decimal("12000.00"),
            date_report=timezone.now(),
        )

        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("historique"))

        reports = [
            e for e in response.data["results"] if e["type_evenement"] == "REPORT"
        ]
        self.assertEqual(len(reports), 1)
        self.assertEqual(Decimal(reports[0]["montant"]), Decimal("12000.00"))
        self.assertEqual(reports[0]["cycle_numero"], "C-HIST-ALICE-1")

    def test_pagination_respecte_page_size(self):
        # Ajoute suffisamment d'opérations pour dépasser une petite page.
        for i in range(5):
            Operation.objects.create(
                client=self.alice, cycle=self.cycle_alice,
                montant=Decimal("1000.00"), type_operation=Operation.TYPE_COTISATION,
                statut=Operation.STATUT_VALIDEE, reference=f"HIST-PAGE-{i}",
            )

        self.client.force_authenticate(user=self.alice)
        response = self.client.get(reverse("historique"), {"page_size": 3})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]), 3)
        self.assertGreaterEqual(response.data["count"], 7)
