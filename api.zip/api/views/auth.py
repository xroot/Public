# api/views/auth.py
from django.contrib.auth import login, logout

from rest_framework import status
from rest_framework.decorators import (
    api_view,
    permission_classes,
    authentication_classes,
)
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.exceptions import NotAuthenticated

from api.authentication import SparkAuthSessionAuthentication
from api.serializers.auth import LoginSerializer, CurrentUserSerializer


@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    """
    Endpoint login : POST /api/login/

    Paramètres :
        - email_or_phone
        - password

    Retour :
        - utilisateur authentifié
        - session Django créée
        - statut HTTP 200
    """
    serializer = LoginSerializer(data=request.data)

    if serializer.is_valid():
        user = serializer.validated_data.get('user')

        login(request, user)

        return Response(
            {
                'message': 'Authentification réussie',
                'user': serializer.to_representation(
                    serializer.validated_data
                )
            },
            status=status.HTTP_200_OK
        )

    return Response(
        {'errors': serializer.errors},
        status=status.HTTP_400_BAD_REQUEST
    )


@api_view(['POST'])
@authentication_classes([SparkAuthSessionAuthentication])
@permission_classes([AllowAny])
def logout_view(request):
    """
    Endpoint logout : POST /api/logout/

    Supprime la session utilisateur.

    Une requête sans authentification retourne HTTP 401.
    """
    if not request.user.is_authenticated:
        raise NotAuthenticated()

    logout(request)

    return Response(
        {'message': 'Déconnexion réussie'},
        status=status.HTTP_200_OK
    )


@api_view(['GET'])
@authentication_classes([SparkAuthSessionAuthentication])
@permission_classes([AllowAny])
def current_user_view(request):
    """
    Endpoint utilisateur courant : GET /api/me/

    Retourne le profil de l'utilisateur connecté.

    Une requête sans authentification retourne HTTP 401.
    """
    if not request.user.is_authenticated:
        raise NotAuthenticated()

    serializer = CurrentUserSerializer(request.user)

    return Response(
        serializer.data,
        status=status.HTTP_200_OK
    )