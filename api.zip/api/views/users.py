# api/views/users.py
from rest_framework.generics import (
    CreateAPIView,
    ListCreateAPIView,
    RetrieveAPIView,
)
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import CustomUser
from api.permissions import HasDjangoPermission
from api.serializers.user import RegisterSerializer, UserSerializer


class UserListView(ListCreateAPIView):
    """
    Liste et création des utilisateurs SPARK.
    """

    queryset = CustomUser.objects.all().order_by("id")
    serializer_class = UserSerializer

    def get_permissions(self):
        if self.request.method == "POST":
            self.required_permission = "accounts.add_customuser"
        else:
            self.required_permission = "accounts.view_customuser"

        return [HasDjangoPermission()]


class UserDetailView(RetrieveAPIView):
    """
    Retourne les informations d'un utilisateur SPARK.
    """

    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = [HasDjangoPermission]
    required_permission = "accounts.view_customuser"


class CurrentUserView(APIView):
    """
    Retourne les informations de l'utilisateur actuellement authentifié.

    GET /api/users/me/
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


class RegisterView(CreateAPIView):
    """
    Inscription publique d'un utilisateur SPARK.
    """

    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]
class CurrentUserView(APIView):
    """
    Retourne les informations de l'utilisateur actuellement authentifié.

    GET /api/users/me/
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)


class RegisterView(CreateAPIView):
    """
    Inscription publique d'un utilisateur SPARK.
    """

    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]
