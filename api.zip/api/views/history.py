# api/views/history.py
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from cycles.models import Cycle, Operation

from api.serializers.history import HistoriqueEvenementSerializer


class HistoriqueView(APIView):
    """
    GET /api/historique/

    Vue en lecture seule qui combine, dans un flux chronologique unique
    et strictement filtré sur le client connecté :
        - les opérations liées à un Cycle ;
        - les opérations liées à une Recharge ;
        - les événements de report (REPORTER) entre cycles.

    Cette vue n'implémente et ne recalcule aucune règle métier : elle
    assemble et trie des données déjà présentes sur les modèles
    Cycle / Operation, conformément au principe architectural de SPARK.

    Pagination simple par page/page_size (défaut : 20 par page).
    """

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        evenements = []

        # -----------------------------------------------------------
        # Opérations (Cycle ou Recharge)
        # -----------------------------------------------------------
        operations = (
            Operation.objects
            .filter(client=user)
            .select_related("cycle", "recharge_cycle", "recharge_cycle__cycle")
        )

        for operation in operations:
            if operation.cycle_id:
                origine = "CYCLE"
                cycle_numero = operation.cycle.numero
            elif operation.recharge_cycle_id:
                origine = "RECHARGE"
                recharge = operation.recharge_cycle
                cycle_numero = recharge.cycle.numero if recharge.cycle_id else None
            else:
                origine = "INCONNUE"
                cycle_numero = None

            evenements.append({
                "type_evenement": operation.type_operation,
                "date": operation.date_operation,
                "origine": origine,
                "cycle_numero": cycle_numero,
                "montant": operation.montant,
                "statut": operation.statut,
                "reference": operation.reference,
                "description": operation.description,
            })

        # -----------------------------------------------------------
        # Événements de report (REPORTER) entre cycles
        # -----------------------------------------------------------
        cycles_reportes = (
            Cycle.objects
            .filter(client=user, date_report__isnull=False)
            .select_related("cycle_precedent")
        )

        for cycle in cycles_reportes:
            numero_precedent = (
                cycle.cycle_precedent.numero
                if cycle.cycle_precedent_id else None
            )
            evenements.append({
                "type_evenement": "REPORT",
                "date": cycle.date_report,
                "origine": "REPORT",
                "cycle_numero": numero_precedent,
                "montant": cycle.montant_reporte,
                "statut": None,
                "reference": f"Report vers {cycle.numero}",
                "description": (
                    f"Report du solde de {numero_precedent} vers {cycle.numero}"
                    if numero_precedent else f"Report vers {cycle.numero}"
                ),
            })

        # -----------------------------------------------------------
        # Tri chronologique (le plus récent en premier)
        # -----------------------------------------------------------
        evenements.sort(key=lambda e: e["date"], reverse=True)

        # -----------------------------------------------------------
        # Pagination simple
        # -----------------------------------------------------------
        try:
            page = max(int(request.query_params.get("page", 1)), 1)
        except (TypeError, ValueError):
            page = 1

        try:
            page_size = int(request.query_params.get("page_size", 20))
            page_size = min(max(page_size, 1), 100)
        except (TypeError, ValueError):
            page_size = 20

        start = (page - 1) * page_size
        end = start + page_size
        page_evenements = evenements[start:end]

        serializer = HistoriqueEvenementSerializer(page_evenements, many=True)

        return Response({
            "count": len(evenements),
            "page": page,
            "page_size": page_size,
            "results": serializer.data,
        })


