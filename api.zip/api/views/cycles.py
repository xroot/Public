# api/views/cycles.py

from rest_framework import status
from rest_framework.generics import (
    ListCreateAPIView,
    RetrieveUpdateDestroyAPIView,
)
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from cycles.models import Cycle

from api.serializers.cycle import (
    CycleCreateSerializer,
    CycleChoixSerializer,
    CycleReporterSerializer,
    CycleSerializer,
)


class CycleListView(ListCreateAPIView):
    """
    GET  /api/cycles/
    POST /api/cycles/

    Liste et création des cycles du client connecté.
    """

    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            Cycle.objects
            .filter(client=self.request.user)
            .select_related(
                "client",
                "cycle_precedent",
            )
            .order_by("-date_debut", "-numero")
        )

    def get_serializer_class(self):
        if self.request.method == "POST":
            return CycleCreateSerializer

        return CycleSerializer


class CycleDetailView(RetrieveUpdateDestroyAPIView):
    """
    GET    /api/cycles/{id}/
    PUT    /api/cycles/{id}/
    PATCH  /api/cycles/{id}/
    DELETE /api/cycles/{id}/

    Un cycle appartenant à un autre client
    est volontairement invisible et retourne 404.
    """

    permission_classes = [IsAuthenticated]

    lookup_field = "pk"

    def get_queryset(self):
        return (
            Cycle.objects
            .filter(client=self.request.user)
            .select_related(
                "client",
                "cycle_precedent",
            )
        )

    def get_serializer_class(self):
        if self.request.method in ["PUT", "PATCH"]:
            return CycleCreateSerializer

        return CycleSerializer


class CycleActiverView(APIView):
    """
    POST /api/cycles/{id}/activer/

    Délègue entièrement l'activation au moteur métier Cycle.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            cycle = (
                Cycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle_precedent",
                )
                .get()
            )
        except Cycle.DoesNotExist:
            return Response(
                {"detail": "Cycle introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = cycle.activer()

        if not success:
            return Response(
                {
                    "message": message,
                    "cycle": CycleSerializer(cycle).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "cycle": CycleSerializer(cycle).data,
            },
            status=status.HTTP_200_OK,
        )


class CycleCloturerView(APIView):
    """
    POST /api/cycles/{id}/cloturer/

    Délègue entièrement la clôture au moteur métier Cycle.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            cycle = (
                Cycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle_precedent",
                )
                .get()
            )
        except Cycle.DoesNotExist:
            return Response(
                {"detail": "Cycle introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = cycle.cloturer()

        if not success:
            return Response(
                {
                    "message": message,
                    "cycle": CycleSerializer(cycle).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "cycle": CycleSerializer(cycle).data,
            },
            status=status.HTTP_200_OK,
        )


class CycleChoixView(APIView):
    """
    POST /api/cycles/{id}/choix/

    Enregistre le choix du client pour un cycle incomplet.

    Exemple :
        {
            "choix": "REPORTER"
        }

    ou :
        {
            "choix": "UTILISER"
        }

    La logique métier est entièrement déléguée à :
        Cycle.enregistrer_choix_client()
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            cycle = (
                Cycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle_precedent",
                )
                .get()
            )
        except Cycle.DoesNotExist:
            return Response(
                {"detail": "Cycle introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = CycleChoixSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        choix = serializer.validated_data["choix"]

        success, message = cycle.enregistrer_choix_client(choix)

        if not success:
            return Response(
                {
                    "message": message,
                    "cycle": CycleSerializer(cycle).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "cycle": CycleSerializer(cycle).data,
            },
            status=status.HTTP_200_OK,
        )


class CycleReporterView(APIView):
    """
    POST /api/cycles/{id}/reporter/

    Effectue le report à nouveau vers un nouveau cycle.

    Les dates sont facultatives.

    Exemple :
        {
            "date_debut": "2026-12-01T00:00:00Z",
            "date_fin": "2027-02-28T23:59:59Z"
        }

    Si les dates ne sont pas fournies, le moteur métier
    Cycle.reporter_vers_nouveau_cycle() applique ses propres
    valeurs par défaut.

    La logique métier du report reste entièrement dans Cycle.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            cycle = (
                Cycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle_precedent",
                )
                .get()
            )
        except Cycle.DoesNotExist:
            return Response(
                {"detail": "Cycle introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = CycleReporterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        date_debut = serializer.validated_data.get("date_debut")
        date_fin = serializer.validated_data.get("date_fin")

        success, message = cycle.reporter_vers_nouveau_cycle(
            date_debut=date_debut,
            date_fin=date_fin,
        )

        if not success:
            return Response(
                {
                    "message": message,
                    "cycle": CycleSerializer(cycle).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        nouveau_cycle = cycle.cycle_suivant

        return Response(
            {
                "message": message,
                "cycle_source": CycleSerializer(cycle).data,
                "nouveau_cycle": CycleSerializer(nouveau_cycle).data,
            },
            status=status.HTTP_201_CREATED,
        )