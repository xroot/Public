# api/views/recharge.py

from rest_framework import status
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from cycles.models import RechargeCycle

from api.serializers.recharge import RechargeCycleSerializer


class RechargeCycleListView(ListAPIView):
    """
    GET /api/recharges/

    Liste les sous-tontines Recharge du client connecté.

    Un utilisateur ne peut jamais récupérer les Recharge
    d'un autre client.
    """

    serializer_class = RechargeCycleSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            RechargeCycle.objects
            .filter(client=self.request.user)
            .select_related(
                "client",
                "cycle",
                "cycle_origine",
            )
            .order_by("-date_debut", "-id")
        )


class RechargeCycleDetailView(RetrieveAPIView):
    """
    GET /api/recharges/<id>/

    Retourne le détail d'une Recharge appartenant
    au client connecté.
    """

    serializer_class = RechargeCycleSerializer
    permission_classes = [IsAuthenticated]

    lookup_field = "pk"

    def get_queryset(self):
        return (
            RechargeCycle.objects
            .filter(client=self.request.user)
            .select_related(
                "client",
                "cycle",
                "cycle_origine",
            )
        )


class RechargeCycleActiverView(APIView):
    """
    POST /api/recharges/<id>/activer/

    Délègue entièrement l'activation au moteur métier
    RechargeCycle.activer().
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            recharge = (
                RechargeCycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle",
                    "cycle_origine",
                )
                .get()
            )
        except RechargeCycle.DoesNotExist:
            return Response(
                {"detail": "Recharge introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = recharge.activer()

        if not success:
            return Response(
                {
                    "message": message,
                    "recharge": RechargeCycleSerializer(recharge).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "recharge": RechargeCycleSerializer(recharge).data,
            },
            status=status.HTTP_200_OK,
        )


class RechargeCycleCloturerView(APIView):
    """
    POST /api/recharges/<id>/cloturer/

    Délègue entièrement la clôture au moteur métier
    RechargeCycle.cloturer().
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            recharge = (
                RechargeCycle.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "client",
                    "cycle",
                    "cycle_origine",
                )
                .get()
            )
        except RechargeCycle.DoesNotExist:
            return Response(
                {"detail": "Recharge introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = recharge.cloturer()

        if not success:
            return Response(
                {
                    "message": message,
                    "recharge": RechargeCycleSerializer(recharge).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "recharge": RechargeCycleSerializer(recharge).data,
            },
            status=status.HTTP_200_OK,
        )