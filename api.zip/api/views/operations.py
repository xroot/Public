# api/views/operations.py

from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from cycles.models import Operation

from api.serializers.operation import OperationSerializer


class OperationListView(generics.ListCreateAPIView):
    """
    GET  /api/operations/
    POST /api/operations/

    Liste et création des opérations du client connecté.

    La création dépose uniquement l'opération en EN_ATTENTE.
    La validation métier reste exclusivement dans Operation.valider().
    """

    serializer_class = OperationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            Operation.objects
            .filter(client=self.request.user)
            .select_related(
                "cycle",
                "recharge_cycle",
            )
            .order_by("-date_operation", "-id")
        )

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context["request"] = self.request
        return context


class OperationDetailView(generics.RetrieveAPIView):
    """
    GET /api/operations/<id>/

    Un client ne peut consulter que ses propres opérations.
    """

    serializer_class = OperationSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = "pk"

    def get_queryset(self):
        return (
            Operation.objects
            .filter(client=self.request.user)
            .select_related(
                "cycle",
                "recharge_cycle",
            )
        )


class OperationValiderView(APIView):
    """
    POST /api/operations/<id>/valider/

    Délègue entièrement la validation au moteur métier
    Operation.valider().
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            operation = (
                Operation.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "cycle",
                    "recharge_cycle",
                )
                .get()
            )
        except Operation.DoesNotExist:
            return Response(
                {"detail": "Opération introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = operation.valider()

        if not success:
            return Response(
                {
                    "message": message,
                    "operation": OperationSerializer(operation).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "operation": OperationSerializer(operation).data,
            },
            status=status.HTTP_200_OK,
        )


class OperationRejeterView(APIView):
    """
    POST /api/operations/<id>/rejeter/

    Délègue entièrement le rejet au moteur métier
    Operation.rejeter().
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            operation = (
                Operation.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "cycle",
                    "recharge_cycle",
                )
                .get()
            )
        except Operation.DoesNotExist:
            return Response(
                {"detail": "Opération introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = operation.rejeter()

        if not success:
            return Response(
                {
                    "message": message,
                    "operation": OperationSerializer(operation).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "operation": OperationSerializer(operation).data,
            },
            status=status.HTTP_200_OK,
        )


class OperationAnnulerView(APIView):
    """
    POST /api/operations/<id>/annuler/

    Délègue entièrement l'annulation au moteur métier
    Operation.annuler().
    """

    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        try:
            operation = (
                Operation.objects
                .filter(
                    pk=pk,
                    client=request.user,
                )
                .select_related(
                    "cycle",
                    "recharge_cycle",
                )
                .get()
            )
        except Operation.DoesNotExist:
            return Response(
                {"detail": "Opération introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )

        success, message = operation.annuler()

        if not success:
            return Response(
                {
                    "message": message,
                    "operation": OperationSerializer(operation).data,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        return Response(
            {
                "message": message,
                "operation": OperationSerializer(operation).data,
            },
            status=status.HTTP_200_OK,
        )