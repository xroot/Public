# api/urls.py

from django.urls import path

from api.views import (
    health,
    users,
    cycles,
    operations,
    recharge,
    history,
    auth,
)

urlpatterns = [
    path(
        "health/",
        health.health_check,
        name="health-check",
    ),

    # ============================================================
    # AUTHENTIFICATION
    # ============================================================

    path(
        "login/",
        auth.login_view,
        name="login",
    ),

    path(
        "logout/",
        auth.logout_view,
        name="logout",
    ),

    path(
        "me/",
        auth.current_user_view,
        name="current-user",
    ),

    # ============================================================
    # UTILISATEURS
    # ============================================================

    path(
        "users/",
        users.UserListView.as_view(),
        name="user-list",
    ),

    path(
        "users/me/",
        users.CurrentUserView.as_view(),
        name="user-current",
    ),

    path(
        "register/",
        users.RegisterView.as_view(),
        name="register",
    ),

    # ============================================================
    # CYCLES
    # ============================================================

    path(
        "cycles/",
        cycles.CycleListView.as_view(),
        name="cycles",
    ),

    path(
        "cycles/<int:pk>/",
        cycles.CycleDetailView.as_view(),
        name="cycle-detail",
    ),

    path(
        "cycles/<int:pk>/activer/",
        cycles.CycleActiverView.as_view(),
        name="cycle-activer",
    ),

    path(
        "cycles/<int:pk>/cloturer/",
        cycles.CycleCloturerView.as_view(),
        name="cycle-cloturer",
    ),

    path(
        "cycles/<int:pk>/choix/",
        cycles.CycleChoixView.as_view(),
        name="cycle-choix",
    ),

    path(
        "cycles/<int:pk>/reporter/",
        cycles.CycleReporterView.as_view(),
        name="cycle-reporter",
    ),

    # ============================================================
    # OPERATIONS
    # ============================================================

    path(
        "operations/",
        operations.OperationListView.as_view(),
        name="operations",
    ),

    path(
        "operations/<int:pk>/",
        operations.OperationDetailView.as_view(),
        name="operation-detail",
    ),

    path(
        "operations/<int:pk>/valider/",
        operations.OperationValiderView.as_view(),
        name="operation-valider",
    ),

    path(
        "operations/<int:pk>/rejeter/",
        operations.OperationRejeterView.as_view(),
        name="operation-rejeter",
    ),

    path(
        "operations/<int:pk>/annuler/",
        operations.OperationAnnulerView.as_view(),
        name="operation-annuler",
    ),

    # ============================================================
    # RECHARGES
    # ============================================================

    path(
        "recharges/",
        recharge.RechargeCycleListView.as_view(),
        name="recharges",
    ),

    path(
        "recharges/<int:pk>/",
        recharge.RechargeCycleDetailView.as_view(),
        name="recharge-detail",
    ),

    path(
        "recharges/<int:pk>/activer/",
        recharge.RechargeCycleActiverView.as_view(),
        name="recharge-activer",
    ),

    path(
        "recharges/<int:pk>/cloturer/",
        recharge.RechargeCycleCloturerView.as_view(),
        name="recharge-cloturer",
    ),

    # ============================================================
    # HISTORIQUE
    # ============================================================

    path(
        "historique/",
        history.HistoriqueView.as_view(),
        name="historique",
    ),
]
